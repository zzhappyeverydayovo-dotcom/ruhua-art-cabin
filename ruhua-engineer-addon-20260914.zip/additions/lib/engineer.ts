export const ENGINEERS = [
  {id:'food', name:'未来食品工程师', subtitle:'用好奇心，创造未来的味道'},
  {id:'biology', name:'未来生物工程师', subtitle:'探索生命，发现新的可能'},
  {id:'bridge', name:'未来桥梁工程师', subtitle:'连接世界，搭建未来的道路'},
  {id:'quantum', name:'未来量子工程师', subtitle:'走进微观世界，解开宇宙奥秘'},
] as const;
export type EngineerId = typeof ENGINEERS[number]['id'];
export type Draw = {id:EngineerId; remaining:EngineerId[]};
/** Refill only after every identity was used. Avoid repeating across bag boundaries. */
export function drawEngineer(remaining: readonly EngineerId[], last?:EngineerId, random:()=>number=Math.random):Draw {
  const pool:EngineerId[] = remaining.length ? [...remaining] : ENGINEERS.map(x=>x.id);
  const eligible = pool.filter(x=>x!==last);
  const choices = eligible.length ? eligible : pool;
  const id=choices[Math.min(choices.length-1, Math.max(0,Math.floor(random()*choices.length)))];
  return {id, remaining:pool.filter(x=>x!==id)};
}
export function engineerPoster(gender:'male'|'female',id:EngineerId) { return `/engineers/${gender}-${id}.webp`; }
