import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ENGINEERS,drawEngineer,engineerPoster,type EngineerId} from './engineer.ts';
import {access} from 'node:fs/promises';
test('four unique identities per cycle, including no immediate repeat at cycle boundary',()=>{
 for(const random of [()=>0,()=>0.999,Math.random]) {
  let remaining:EngineerId[]=[]; let last:EngineerId|undefined;
  for(let cycle=0;cycle<20;cycle++) { const seen=new Set();
   for(let j=0;j<4;j++){ const next=drawEngineer(remaining,last,random); assert.notEqual(next.id,last); seen.add(next.id);remaining=next.remaining;last=next.id; }
   assert.equal(seen.size,4);assert.equal(remaining.length,0);
  }
 }
});
test('all eight child poster assets exist',async()=>{
 for(const gender of ['male','female'] as const) for(const item of ENGINEERS) await access(new URL(`../public${engineerPoster(gender,item.id)}`,import.meta.url));
});
