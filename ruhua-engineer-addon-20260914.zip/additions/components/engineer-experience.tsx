'use client';
/* oxlint-disable next/no-img-element */
import {useEffect,useRef,useState,type ReactNode} from 'react';
import {ArrowLeft,ArrowRight,Home,Camera,RefreshCw,Download,Atom,Sparkles,Check} from 'lucide-react';
import {ENGINEERS,drawEngineer,engineerPoster,type EngineerId} from '@/lib/engineer';
import {parseResult,safeUrl,type Result} from '@/lib/flow';
import './engineer.css';

function Shell({children,onBack,onHome}:{children:ReactNode;onBack:()=>void;onHome:()=>void}) {
 return <main className="eng-studio"><section className="eng-cabin"><nav className="eng-nav"><button onClick={onBack}><ArrowLeft/> 返回</button><span>入画 · 下一百廿年</span><button onClick={onHome}><Home/> 首页</button></nav>{children}<footer className="eng-footer">1906 — 2026 — 2146</footer></section></main>;
}
export function ExperiencePicker({onHome,onChoose}:{onHome:()=>void;onChoose:(v:'artist'|'engineer')=>void}) {
 return <Shell onBack={onHome} onHome={onHome}><header className="eng-heading"><p>未来，从好奇开始</p><h1>你想开启<br/>哪一种未来？</h1><span>轻触一个世界，开始你的入画之旅</span></header><div className="eng-paths"><button onClick={()=>onChoose('artist')}><Sparkles/><small>ART × IMAGINATION</small><h2>未来艺术家</h2><p>用创造力，描绘下一百廿年</p><span>探索八种艺术身份 <ArrowRight/></span></button><button className="eng-science" onClick={()=>onChoose('engineer')}><Atom/><small>SCIENCE × CURIOSITY</small><h2>未来小小工程师</h2><p>让小小的好奇，遇见大大的未来</p><span>开启我的科学奇遇 <ArrowRight/></span></button></div><p className="eng-caption">每一种想象，都有属于你的模样</p></Shell>;
}

function PosterQr({result}:{result:Result}) {
 return <section className="eng-scan-card" aria-label="扫码保存海报"><div className="eng-scan-label">你的未来，值得珍藏</div><div className="eng-scan-code">{result.downloadQr?<img src={result.downloadQr} alt="本张海报的保存二维码"/>:<div className="eng-qr-empty">二维码待接入</div>}</div><h2>扫码保存海报</h2><p>打开手机扫一扫<br/>进入海报页面，长按图片保存</p></section>;
}

type Stage='gender'|'photo'|'loading'|'preview'|'save';
export function EngineerExperience({endpoint,onBack,onHome}:{endpoint:string;onBack:()=>void;onHome:()=>void}) {
 const [stage,setStage]=useState<Stage>('gender');
 const [gender,setGender]=useState<'male'|'female'>('male');
 const [photo,setPhoto]=useState('');
 const [stream,setStream]=useState<MediaStream|null>(null);
 const [cameraBusy,setCameraBusy]=useState(false);
 const [error,setError]=useState('');
 const [job,setJob]=useState<{id:EngineerId;token:string}|null>(null);
 const [result,setResult]=useState<Result|null>(null);
 const [progress,setProgress]=useState(0);
 const video=useRef<HTMLVideoElement>(null);
 const streamRef=useRef<MediaStream|null>(null);
 const captureEpoch=useRef(0);
 const bag=useRef<EngineerId[]>([]);
 const last=useRef<EngineerId|undefined>(undefined);
 const busy=useRef(false);
 const titleRef=useRef<HTMLHeadingElement>(null);
 const stopCamera=()=>{captureEpoch.current++;streamRef.current?.getTracks().forEach(t=>t.stop());streamRef.current=null;setStream(null);setCameraBusy(false);};
 useEffect(()=>()=>{captureEpoch.current++;streamRef.current?.getTracks().forEach(t=>t.stop());},[]);
 useEffect(()=>{if(video.current && stream) {video.current.srcObject=stream;void video.current.play().catch(()=>setError('请允许摄像头播放，再完成现场拍摄。'));}},[stream]);
 useEffect(()=>{titleRef.current?.focus();},[stage]);
 const openCamera=async()=>{
  setError('');setCameraBusy(true);const epoch=++captureEpoch.current;
  try {
   if(!navigator.mediaDevices?.getUserMedia) throw Error('摄像头需要 HTTPS 或本机 localhost，请联系现场工作人员。');
   const media=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:1280},height:{ideal:1280}},audio:false});
   if(epoch!==captureEpoch.current){media.getTracks().forEach(t=>t.stop());return;}
   streamRef.current?.getTracks().forEach(t=>t.stop());streamRef.current=media;setPhoto('');setStream(media);
  } catch(e) {if(epoch===captureEpoch.current)setError((e as Error).message.includes('HTTPS')?(e as Error).message:'摄像头未能打开，请允许相机权限并重试，或联系现场工作人员。');}
  finally{if(epoch===captureEpoch.current)setCameraBusy(false);}
 };
 useEffect(()=>{if(stage==='photo'){void openCamera();return()=>{captureEpoch.current++;streamRef.current?.getTracks().forEach(t=>t.stop());streamRef.current=null;};}},[stage]);
 const capture=()=>{
  const v=video.current;if(!v?.videoWidth){setError('相机正在准备，请稍后再拍。');return;}
  const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d')?.drawImage(v,0,0);setPhoto(c.toDataURL('image/jpeg',0.9));stopCamera();setError('');
 };
 const generate=(retry=false)=>{
  if(busy.current||!photo)return;busy.current=true;setError('');stopCamera();
  let id=job?.id;
  if(!retry||!id){const draw=drawEngineer(bag.current,last.current);bag.current=draw.remaining;last.current=draw.id;id=draw.id;}
  setJob({id,token:crypto.randomUUID()});setStage('loading');
 };
 useEffect(()=>{
  if(stage!=='loading'||!job)return;
  const controller=new AbortController();let active=true;let timer:ReturnType<typeof setTimeout>|undefined;
  setProgress(0);setResult(null);
  const tick=setInterval(()=>setProgress(p=>Math.min(90,p+3)),180);
  const delay=(ms:number)=>new Promise<void>((resolve,reject)=>{timer=setTimeout(resolve,ms);controller.signal.addEventListener('abort',()=>{clearTimeout(timer);reject(new DOMException('Aborted','AbortError'));},{once:true});});
  const timeout=setTimeout(()=>controller.abort(),120000);
  void (async()=>{
   try {
    let next:Result;
    if(endpoint){
     if(!safeUrl(endpoint))throw Error('生成服务地址无效，请联系现场工作人员。');
     const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({experience:'little-engineer',ageGroup:'child',gender,identity:job.id,photoDataUrl:photo,requestId:job.token})});
     if(!response.ok)throw Error('生成暂时未完成，请重试。');next=parseResult(await response.json());
    } else {await delay(3500);next={imageUrl:engineerPoster(gender,job.id),demo:true};}
    const img=new Image();img.src=next.imageUrl!;
    await Promise.race([img.decode(),new Promise<never>((_,reject)=>{if(controller.signal.aborted)reject(new DOMException('Aborted','AbortError'));else controller.signal.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true});})]);
    if(!active||controller.signal.aborted)return;
    setProgress(100);await delay(450);if(!active)return;
    setResult(next);setStage('preview');busy.current=false;
    window.dispatchEvent(new CustomEvent('ruhua:engineer-poster-ready',{detail:{requestId:job.token,experience:'little-engineer',gender,identity:job.id,...next}}));
   }catch(e){if(active){setError(controller.signal.aborted?'生成超时，请重试或返回重新拍照。':(e as Error).message||'海报加载失败，请重试。');busy.current=false;}}
  })();
  return()=>{active=false;controller.abort();clearInterval(tick);clearTimeout(timeout);clearTimeout(timer);};
 },[stage,job,endpoint,gender,photo]);
 const back=()=>{stopCamera();busy.current=false;setError('');if(stage==='gender')onBack();else if(stage==='photo'){setPhoto('');bag.current=[];last.current=undefined;setStage('gender');}else if(stage==='save')setStage('preview');else setStage('photo');};
 const leave=()=>{stopCamera();onHome();};
 const current=ENGINEERS.find(x=>x.id===job?.id);
 const steps=['读取创造力信号','探索未来科学方向','唤醒小小工程潜能','完成未来职业肖像'];
 return <Shell onBack={back} onHome={leave}>
  <header className="eng-heading eng-heading-small"><p>未来小小工程师</p><h1 ref={titleRef} tabIndex={-1}>{stage==='gender'?'你的未来，以什么形象登场？':stage==='photo'?'把你的好奇，交给未来':stage==='loading'?'未来正在学习你的样子':stage==='preview'?'未来已经认出你':'把未来带回此刻'}</h1><span>{stage==='gender'?'轻触一种形象，下一步拍照':stage==='photo'?'面对镜头，拍下清晰的正面照片':stage==='loading'?'稍等片刻，一场科学奇遇即将揭晓':stage==='preview'?'喜欢就保存，也可以换一个科学身份':'用手机扫一扫，珍藏你的未来模样'}</span></header>
  {stage==='gender'&&<><div className="eng-genders">{(['male','female'] as const).map(g=><button key={g} onClick={()=>{setGender(g);setStage('photo');}}><img src={engineerPoster(g,'quantum')} alt=""/><span>{g==='male'?'男生形象':'女生形象'}<ArrowRight/></span></button>)}</div><p className="eng-caption">四种科学身份，随机开启一种可能</p></>}
  {stage==='photo'&&<div className="eng-photo"><div className="eng-camera-frame">{photo?<img src={photo} alt="本次拍摄照片"/>:stream?<video ref={video} autoPlay muted playsInline aria-label="摄像头预览"/>:<div className="eng-camera-idle"><Camera/><p>让未来看见你的样子</p></div>}<i/><i/><i/><i/></div><div className="eng-actions">{photo?<><button className="eng-primary" onClick={()=>generate()}><Sparkles/>用这张照片，开启未来</button><button onClick={()=>{setPhoto('');void openCamera();}}>重新拍照</button></>:<><button className="eng-primary" disabled={cameraBusy} onClick={()=>stream?capture():void openCamera()}><Camera/>{cameraBusy?'正在打开相机…':stream?'拍下这一刻':'重新开启摄像头'}</button></>}</div><p className="eng-note">{endpoint?'确认照片后，将发送至海报生成服务。':'当前为模板演示：照片仅用于体验拍照步骤，不会上传或替换海报人脸。'}</p></div>}
  {stage==='loading'&&<div className="eng-loading"><div className="eng-atom"><Atom/><i/><i/><i/></div><p>连接2146年的你</p><div className="eng-progress" role="progressbar" aria-label="生成进度" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}><span style={{width:`${progress}%`}}/></div><ol>{steps.map((s,i)=><li key={s} className={progress>=i*25?'lit':''}><span>{progress>(i+1)*25?<Check/>:`0${i+1}`}</span>{s}</li>)}</ol>{error&&<button className="eng-primary" onClick={()=>generate(true)}>重新生成</button>}</div>}
  {stage==='preview'&&result&&<div className="eng-result"><div className="eng-poster"><img src={result.imageUrl!} alt={`${gender==='male'?'男生':'女生'}${current?.name}海报`}/></div><h2>{current?.name}</h2><p>{current?.subtitle}</p>{result.demo&&<small className="eng-demo">海报模板预览 · 尚未进行真人生成</small>}<div className="eng-actions"><button className="eng-primary" onClick={()=>setStage('save')}><Download/> 保存海报 <ArrowRight/></button><button onClick={()=>generate()}><RefreshCw/> 换一个身份</button></div></div>}
  {stage==='save'&&result&&<div className="eng-save"><div className="eng-saved-poster"><img src={result.imageUrl!} alt={`${current?.name}海报`}/><div><span>你的未来身份</span><h2>{current?.name}</h2><p>{current?.subtitle}</p></div></div><PosterQr result={result}/><p className="eng-save-tip">保存完成后，点击下方按钮结束体验</p><div className="eng-actions"><button className="eng-primary" onClick={leave}><Check/> 完成，返回首页</button><button onClick={()=>setStage('preview')}>返回查看海报</button></div></div>}
  {error&&<p className="eng-error" role="alert">{error}</p>}
 </Shell>;
}
