# 未来小小工程师 · v1.1 技术对接

## 已实现的页面流程
首页动画 → 开启未来 → 未来艺术家 / 未来小小工程师。

未来艺术家保留原有男女、八身份、同身份换图流程。
未来小小工程师：男生 / 女生 → 自动开启摄像头现场拍照→ 确认照片 → 等待 → 随机儿童工程师海报 → 保存海报 → 扫码保存页 → 完成，返回首页。

四种身份：食品 food、生物 biology、桥梁 bridge、量子 quantum。第四组按用户确认使用桥梁，非材料。每个性别各四张海报，全部为儿童。换一个身份保留本次性别和照片；四种不重复抽取，抽完后重置，跨轮不连续重复。返回上一步可重拍；首页结束当前会话。未开启自动人脸/性别识别。

## 当前演示与正式服务边界
默认 engineerEndpoint 为空。拍摄照片仅保留在浏览器当前会话内，不上传、不持久化；输出是提供的海报模板，不进行换脸。真实AI生成、公开扫码下载、另一台电脑接收/归档都尚未部署。

相机使用浏览器 getUserMedia，需要 HTTPS 或 localhost，以及相机权限。不提供照片上传，只允许现场采集。首次进入须允许浏览器相机权限。相机离开拍照时停止。Unity 原生摄像头请由 Unity 端接入，再调用相同生成协议。

## 正式海报接口
修改 public/ruhua-config.json 的 engineerEndpoint；艺术家使用原 generationEndpoint，两者独立。

POST engineerEndpoint，Content-Type: application/json：

```json
{
  "experience": "little-engineer",
  "ageGroup": "child",
  "gender": "male",
  "identity": "food",
  "photoDataUrl": "data:image/jpeg;base64,...",
  "requestId": "每次请求的唯一UUID"
}
```

gender 为 male / female；identity 为 food / biology / bridge / quantum。
响应 200 JSON（imageUrl 必需，其余可选）：

```json
{
  "imageUrl": "https://your-host.example/results/id.webp",
  "downloadUrl": "https://your-host.example/download/id",
  "downloadQr": "https://your-host.example/qr/id.png"
}
```

imageUrl 为可直接加载的完整最终海报，不是原始拍照图。downloadQr 必须由服务端根据同一结果的有效公开下载地址生成。示例域名仅说明字段，需替换。跨域服务需允许本站来源；HTTPS 页面不得使用 HTTP 接口。前端不存储服务密钥，密钥放服务端。120秒超时可重试；取消/返回后旧结果不会替换当前页面。

## 外接显示设备预留事件
每张海报成功加载后，浏览器触发 `ruhua:engineer-poster-ready` CustomEvent，detail 包含 requestId / experience / gender / identity / imageUrl / demo，以及返回的下载信息。该事件仅在当前页面内广播，不会自动传到另一台主机。

推荐在生成服务器完成最终图片后，向展示主机投递结果并落盘，按 requestId 去重、失败重试。demo=true 的模板演示不要进入正式作品归档。外屏轮播/接收服务需技术方单独接入。

## 文件
- components/engineer-experience.tsx：入口、男女、拍照、等待、结果/保存。
- components/engineer.css：响应式竖屏、深蓝金色与青色光效。
- lib/engineer.ts：身份表、抽取规则、图片路径。
- public/engineers：8张 WebP 海报，名称 male/female-food/biology/bridge/quantum.webp。
- lib/engineer.test.ts：循环不重复与资源存在检查。

## 运行与检查
Node.js 22.13 或更新版本。完整包解压后进入 ruhua-system：

```sh
npm ci
npm run dev
```

浏览器打开终端显示的本机地址。生产静态输出：

```sh
npm run build
```

将 dist/client 的内容部署到网站根目录；不要直接 file:// 打开，不要部署到仓库名子路径。无需登录 ChatGPT 访问独立部署的网站。

检查命令：`node --experimental-strip-types --test lib/flow.test.ts lib/engineer.test.ts`；`npx tsc --noEmit`。

## 扫码保存界面
点击保存海报进入独立扫码页，展示本张海报缩略图、身份和二维码预留位置。与未来艺术家一致：有 downloadQr 时显示，没有时显示“二维码待接入”，不在前端生成二维码。返回可查看同一张海报，完成按钮结束体验。
