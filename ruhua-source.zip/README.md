# 入画 · 全息舱交互系统

完整前端体验：20秒原版首页循环视频 → 男生/女生 → 四方向/八身份 → 双身份 → 加载 → 海报预览/换一张 → 保存方式 → 纯海报/海报＋导览。

## 本地运行

需要 Node.js 22.13 或更高版本。

1. 本仓库已包含运行所需的界面图片、首页视频和32张海报，可直接安装运行，无需另外下载素材。
2. `npm ci`
3. `npm run dev`，打开控制台打印的网址。
4. `npm run build` 输出 `dist/client/`。全息舱可以将整个 dist/client 文件夹放入任意 HTTP 静态服务器；不建议通过 file:// 直接打开。

## 素材与布局

- 最新首页视频：`public/assets/home-original.mp4`，来自用户的“视频节点 1-3.mp4”，720×1280，约20.064秒。视频不含文字，网页只绘制一套文字及按钮。
- 海报显示框严格 `aspect-ratio: 942 / 1670`，图片使用 `object-fit: contain`。不会裁切海报或拉伸人物。
- 32张海报已按男生/女生×8身份接入，每组2张，默认图排第一。8张标注科技增强的图片已替换为修订成品；二维码与展厅导览仍需接入正式服务。
- 每页透明热区是有可访问名称的真实按钮，支持触摸、鼠标、Tab与Enter。
- 左上返回保持路径选择；右上首页清空当前观众选择。加载返回取消进行中的请求，旧请求完成不能跳转新页面。
- F2或顶部“素材配置”可按人物形象＋身份添加多张本地海报及二维码。仅保留在当前页面内存，不上传服务器，不会分享给其他访问者，刷新后清空。
- 公开站点为协作演示，不包含摄像头、人脸识别或真实AI生成服务。顶部标识当前演示模式。

## 技术对接

编辑 `public/ruhua-config.json`（发布后对应 `/ruhua-config.json`）。默认没有 generationEndpoint，首次以8秒演示加载后展示该组默认海报，换图以1.2秒过渡后展示另一张。固定素材库使用 `posters["male:oriental"]` 等键，值为 Result 数组；variant 按数组长度循环。male代表男生形象，female代表女生形象。

身份ID：oriental 东方智绘师；life 生命织造设计师；ai AI共生艺术家；objects 智能器物设计师；dimensions 多维造型艺术家；cosmos 宇宙叙事建筑师；heritage 非遗再生艺术家；emotion 心灵感知艺术家。

设置 generationEndpoint 为你方的HTTPS服务地址后，每次生成发送POST JSON：

```json
{"gender":"male","identity":"oriental","variant":0}
```

服务返回：

```json
{
  "imageUrl":"https://your-domain.example/poster.png",
  "downloadUrl":"https://your-domain.example/download",
  "guideUrl":"https://your-domain.example/guide",
  "downloadQr":"https://your-domain.example/poster-qr.png",
  "guideQr":"https://your-domain.example/guide-qr.png"
}
```

imageUrl必填，其余可选。二维码字段为真实二维码图片URL，不是下载链接本身。服务应在120秒内返回最终结果；异步任务轮询需由你方服务封装。客户端会先加载海报图片，成功后才亮起最后一步并进入预览。出错显示重试；离开页面触发AbortController。跨域服务需要允许当前公开站点Origin。API密钥放你方服务端，不能写入此公开JSON或浏览器代码。

“换一张”保留gender与identity，variant递增。二维码要对应当前返回海报，不能复用其他观众的结果。二维码缺失时保持待接入，不生成假二维码。

## 校验记录

状态机测试覆盖男生/女生×8身份、四组固定映射、同身份换图、返回路径、旧生成任务作废、非法跳转和服务URL检查。运行 `node --experimental-strip-types --test lib/flow.test.ts`。

WebMCP为渐进增强，未获得支持的运行时验证环境，未宣称验证；常规页面不依赖它。

默认选择补充：生命织造男生、心灵感知男生未标默认，采用校园图；非遗再生男生采用古琴文件为默认。其余13组按用户文件名中的默认标注。
