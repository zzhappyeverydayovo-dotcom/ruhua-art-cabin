import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: '入画 · 下一百廿年',
  description: '预见2146年的自己，开启你的未来艺术身份之旅。',
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
