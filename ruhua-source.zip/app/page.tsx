'use client';
/* Static kiosk artwork and session-local blob images must retain their exact intrinsic rendering. */
/* oxlint-disable next/no-img-element */
import {
  useCallback,
  useEffect,
  useReducer,
  useRef,
  useState,
  type CSSProperties,
} from 'react';
import {
  ArrowRight,
  Maximize,
  Volume2,
  VolumeX,
  Settings2,
  ImagePlus,
  Download,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import {
  IDENTITIES,
  GROUPS,
  initialFlow,
  reducer,
  parseResult,
  safeUrl,
  type Action,
  type Gender,
  type Identity,
  type Result,
  type Screen,
} from '@/lib/flow';

type Config = {
  generationEndpoint: string;
  demoDurationMs: number;
  homeVideo: string;
  posters: Record<string, Result[]>;
};
const DEFAULT: Config = {
  generationEndpoint: '',
  demoDurationMs: 8000,
  homeVideo: '/assets/home-original.mp4',
  posters: {},
};
const TITLES: Record<Screen, string> = {
  home: '预见2146年的自己',
  gender: '未来的你，想以什么形象登场？',
  directions: '你更想与什么建立连接？',
  identities: '哪一种未来正在等你？',
  pair: '你想以哪种身份入画？',
  loading: '未来正在学习你的样子',
  preview: '未来已经认出你',
  save: '把未来带回此刻',
  poster: '把未来带回此刻',
  guide: '把未来带回此刻',
};
const STEPS = [
  '读取创造力信号',
  '匹配未来艺术方向',
  '唤醒天美未来校园',
  '完成未来职业肖像',
];
const GENDER_NAMES = { male: '男生形象', female: '女生形象' };
const rect = (x: number, y: number, w: number, h: number): CSSProperties => ({
  left: `${x}%`,
  top: `${y}%`,
  width: `${w}%`,
  height: `${h}%`,
});
const ORBITS: [Identity, number, number][] = [
  ['oriental', 50, 24],
  ['dimensions', 78, 33],
  ['objects', 89, 47],
  ['cosmos', 78, 63],
  ['life', 50, 71],
  ['emotion', 23, 63],
  ['ai', 11, 47],
  ['heritage', 23, 33],
];

function Hit({
  label,
  box,
  onClick,
  round = false,
}: {
  label: string;
  box: number[];
  onClick: () => void;
  round?: boolean;
}) {
  return (
    <Button
      className={`hit ${round ? 'round' : ''}`}
      style={rect(box[0], box[1], box[2], box[3])}
      onClick={onClick}
      aria-label={label}
    >
      <span className="sr-only">{label}</span>
    </Button>
  );
}
function Poster({
  result,
  identity,
  gender,
  variant,
  kind,
  onError,
}: {
  result: Result | null;
  identity: string;
  gender: string;
  variant: number;
  kind: Screen;
  onError: () => void;
}) {
  return (
    <div className={`poster-mat mat-${kind}`}>
      <div className="poster-frame">
        {result?.imageUrl ? (
          <img
            src={result.imageUrl}
            alt={`${gender} · ${identity} · 第${variant + 1}张海报`}
            onError={onError}
          />
        ) : (
          <div className="poster-empty">
            <ImagePlus aria-hidden="true" />
            <strong>海报待添加</strong>
            <i />
            <span>{identity || '未来职业肖像'}</span>
            <small>
              {gender} · 第{variant + 1}张
            </small>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Ruhua() {
  const [flow, dispatch] = useReducer(reducer, initialFlow);
  const [config, setConfig] = useState<Config>(DEFAULT);
  const [ready, setReady] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [muted, setMuted] = useState(true);
  const [videoFailed, setVideoFailed] = useState(false);
  const [videoBlocked, setVideoBlocked] = useState(false);
  const [settings, setSettings] = useState(false);
  const [guideOpen, setGuideOpen] = useState<string | null>(null);
  const [notice, setNotice] = useState('');
  const [assetGender, setAssetGender] = useState<Gender>('male');
  const [assetId, setAssetId] = useState<Identity>('oriental');
  const [pool, setPool] = useState<Record<string, Result[]>>({});
  const rootRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const flowRef = useRef(flow);
  const urls = useRef<string[]>([]);
  useEffect(() => {
    flowRef.current = flow;
  }, [flow]);
  const identity = IDENTITIES.find((i) => i.id === flow.identity)?.name ?? '';
  const gender = flow.gender ? GENDER_NAMES[flow.gender] : '';
  const assetKey = `${assetGender}:${assetId}`;
  const act = useCallback((a: Action) => {
    setNotice('');
    setError('');
    dispatch(a);
  }, []);
  useEffect(() => {
    const c = new AbortController();
    fetch('/ruhua-config.json', { signal: c.signal })
      .then((r) => {
        if (!r.ok) throw Error();
        return r.json() as Promise<Partial<Config>>;
      })
      .then((v) => setConfig({ ...DEFAULT, ...v, posters: v.posters ?? {} }))
      .catch(() => {})
      .finally(() => setReady(true));
    return () => c.abort();
  }, []);
  useEffect(() => {
    const activeUrls = urls.current;
    return () => activeUrls.forEach((u) => URL.revokeObjectURL(u));
  }, []);
  useEffect(() => {
    headingRef.current?.focus({ preventScroll: true });
  }, [flow.screen]);
  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(''), 4500);
    return () => clearTimeout(t);
  }, [notice]);
  useEffect(() => {
    if (flow.screen !== 'home') return;
    void videoRef.current
      ?.play()
      .then(() => setVideoBlocked(false))
      .catch(() => setVideoBlocked(true));
  }, [flow.screen, config.homeVideo]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setSettings((v) => !v);
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);
  useEffect(() => {
    if (flow.screen !== 'loading' || !ready) return;
    const c = new AbortController();
    let alive = true;
    const job = flow.job;
    const resetTimer = setTimeout(() => {
      if (alive) {
        setProgress(0);
        setError('');
        setResult(null);
      }
    }, 0);
    const started = Date.now();
    const duration = flow.variant > 0 && !config.generationEndpoint ? 1200 : Math.max(
      1200,
      Math.min(60000, Number(config.demoDurationMs) || 8000),
    );
    const ticker = setInterval(() => {
      if (alive)
        setProgress(Math.min(86, ((Date.now() - started) / duration) * 86));
    }, 80);
    let timeout: ReturnType<typeof setTimeout>;
    let finish: ReturnType<typeof setTimeout>;
    const run = async () => {
      try {
        let next: Result;
        if (config.generationEndpoint) {
          const endpoint = safeUrl(config.generationEndpoint);
          if (!endpoint) throw Error('海报服务地址无效');
          timeout = setTimeout(() => c.abort(), 120000);
          const r = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              gender: flow.gender,
              identity: flow.identity,
              variant: flow.variant,
            }),
            signal: c.signal,
          });
          if (!r.ok) throw Error('海报暂时没有生成成功，请再试一次');
          next = parseResult(await r.json());
        } else {
          await new Promise<void>((resolve) => {
            timeout = setTimeout(resolve, duration);
          });
          const key = `${flow.gender}:${flow.identity}`;
          const choices = pool[key] ?? config.posters[key] ?? [];
          const chosen = choices.length
            ? choices[flow.variant % choices.length]
            : undefined;
          next = chosen
            ? { ...chosen, demo: true }
            : { imageUrl: null, demo: true };
        }
        if (next.imageUrl)
          await new Promise<void>((resolve, reject) => {
            const img = new Image();
            const timer = setTimeout(
              () => reject(Error('海报图片加载超时，请重试')),
              20000,
            );
            img.onload = () => {
              clearTimeout(timer);
              resolve();
            };
            img.onerror = () => {
              clearTimeout(timer);
              reject(Error('海报图片暂时无法显示，请重试'));
            };
            c.signal.addEventListener(
              'abort',
              () => {
                clearTimeout(timer);
                img.src = '';
                reject(Error('已取消'));
              },
              { once: true },
            );
            img.src = next.imageUrl!;
          });
        if (!alive) return;
        clearInterval(ticker);
        clearTimeout(timeout);
        setProgress(100);
        setResult(next);
        finish = setTimeout(() => {
          if (alive) dispatch({ type: 'ready', job });
        }, 650);
      } catch (e) {
        if (alive) {
          clearInterval(ticker);
          clearTimeout(timeout);
          setError(
            c.signal.aborted
              ? '等待时间较长，请重试或返回选择身份'
              : e instanceof Error
                ? e.message
                : '生成暂时失败，请重试',
          );
        }
      }
    };
    void run();
    return () => {
      alive = false;
      c.abort();
      clearTimeout(resetTimer);
      clearInterval(ticker);
      clearTimeout(timeout);
      clearTimeout(finish);
    };
  }, [
    flow.screen,
    flow.job,
    flow.gender,
    flow.identity,
    flow.variant,
    config,
    ready,
    pool,
  ]);
  useEffect(() => {
    const context = (
      document as Document & {
        modelContext?: {
          registerTool: (
            tool: unknown,
            options: { signal: AbortSignal },
          ) => void;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;
    const life = new AbortController();
    const execute = async (input: unknown) => {
      const v = input as { action?: string; value?: string };
      const s = flowRef.current;
      let action: Action;
      if (v.action === 'read')
        return {
          ...s,
          identityName: IDENTITIES.find((i) => i.id === s.identity)?.name,
          mode: config.generationEndpoint ? 'service' : 'demo',
        };
      if (v.action === 'home') action = { type: 'home' };
      else if (v.action === 'start' && s.screen === 'home')
        action = { type: 'start' };
      else if (
        v.action === 'gender' &&
        s.screen === 'gender' &&
        (v.value === 'male' || v.value === 'female')
      )
        action = { type: 'gender', gender: v.value };
      else if (
        v.action === 'direction' &&
        s.screen === 'directions' &&
        GROUPS.some((g) => g.id === v.value)
      )
        action = {
          type: 'direction',
          group: v.value as (typeof GROUPS)[number]['id'],
        };
      else if (v.action === 'all' && s.screen === 'directions')
        action = { type: 'all' };
      else if (
        v.action === 'identity' &&
        ['pair', 'identities'].includes(s.screen) &&
        IDENTITIES.some((i) => i.id === v.value)
      )
        action = { type: 'identity', identity: v.value as Identity };
      else if (v.action === 'back' && s.screen !== 'home')
        action = { type: 'back' };
      else if (v.action === 'confirm' && s.screen === 'preview')
        action = { type: 'confirm' };
      else if (v.action === 'next' && s.screen === 'preview')
        action = { type: 'next' };
      else if (
        v.action === 'format' &&
        ['save', 'poster', 'guide'].includes(s.screen) &&
        (v.value === 'poster' || v.value === 'guide')
      )
        action = { type: 'format', screen: v.value };
      else throw Error('当前页面不支持该操作或选项无效');
      const next = reducer(s, action);
      if (next === s) throw Error('当前页面不支持该选项');
      act(action);
      await new Promise((r) =>
        requestAnimationFrame(() => requestAnimationFrame(r)),
      );
      return {
        screen: flowRef.current.screen,
        gender: flowRef.current.gender,
        identity: flowRef.current.identity,
      };
    };
    try {
      context.registerTool(
        {
          name: 'ruhua_read_state',
          description: '读取入画当前页面、人物形象和身份选择。',
          inputSchema: {
            type: 'object',
            properties: {},
            additionalProperties: false,
          },
          annotations: { readOnlyHint: true },
          execute: () => execute({ action: 'read' }),
        },
        { signal: life.signal },
      );
      context.registerTool(
        {
          name: 'ruhua_navigate_experience',
          description:
            '操作入画体验。身份选择会开始生成或演示等待，首页会清空当前选择。',
          inputSchema: {
            type: 'object',
            properties: {
              action: {
                type: 'string',
                enum: [
                  'home',
                  'start',
                  'gender',
                  'direction',
                  'all',
                  'identity',
                  'back',
                  'confirm',
                  'next',
                  'format',
                ],
              },
              value: { type: 'string' },
            },
            required: ['action'],
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false },
          execute,
        },
        { signal: life.signal },
      );
    } catch {}
    return () => life.abort();
  }, [act, config.generationEndpoint]);
  const addImages = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      const images = Array.from(files);
      if (
        images.some(
          (f) => !['image/png', 'image/jpeg', 'image/webp'].includes(f.type),
        )
      )
        throw Error('请选择 PNG、JPG 或 WebP 海报');
      if (images.some((f) => f.size > 25 * 1024 * 1024))
        throw Error('每张海报请小于25MB');
      const items = images.map((f) => {
        const url = URL.createObjectURL(f);
        urls.current.push(url);
        return { imageUrl: url, demo: true } as Result;
      });
      setPool((p) => ({
        ...p,
        [assetKey]: [...(p[assetKey] ?? config.posters[assetKey] ?? []), ...items],
      }));
      setNotice(
        `已为${GENDER_NAMES[assetGender]}${IDENTITIES.find((i) => i.id === assetId)?.name}添加${items.length}张海报`,
      );
    } catch (e) {
      setNotice((e as Error).message);
    }
  };
  const addQr = (files: FileList | null, kind: 'downloadQr' | 'guideQr') => {
    const file = files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      setNotice('请选择二维码图片');
      return;
    }
    const url = URL.createObjectURL(file);
    urls.current.push(url);
    setPool((p) => ({
      ...p,
      [assetKey]: ((p[assetKey] ?? config.posters[assetKey])?.length
        ? (p[assetKey] ?? config.posters[assetKey])
        : [{ imageUrl: null, demo: true }]
      ).map((r) => ({ ...r, [kind]: url })),
    }));
    setNotice('二维码已添加，请重新选择该身份查看');
  };
  const fullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await rootRef.current?.requestFullscreen();
    } catch {
      setNotice('当前浏览器不支持全屏，可放大窗口体验');
    }
  };
  const download = () => {
    if (!result?.imageUrl) return;
    const a = document.createElement('a');
    a.href = result.downloadUrl || result.imageUrl;
    a.download = `入画-${gender}-${identity}-${flow.variant + 1}.png`;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.click();
  };
  const scene =
    flow.screen === 'pair'
      ? flow.group
      : flow.screen === 'home'
        ? 'home'
        : flow.screen === 'gender'
          ? 'gender'
          : flow.screen === 'directions'
            ? 'directions'
            : flow.screen === 'identities'
              ? 'identities'
              : flow.screen;
  const qr = flow.screen === 'guide' ? result?.guideQr : result?.downloadQr;
  return (
    <main className="studio">
      <header className="studio-toolbar">
        <span className="studio-brand">
          入画 <small>交互系统</small>
        </span>
        <span className="mode-tag">
          {config.generationEndpoint ? '海报服务模式' : '海报模板体验'}
        </span>
        <div className="tools">
          <a
            className="handoff-link"
            href="/handoff.html"
            target="_blank"
            rel="noopener noreferrer"
          >
            对接说明
          </a>
          <Button
            className="tool"
            onClick={() => setSettings(true)}
            aria-label="素材配置"
          >
            <Settings2 />
            <span>素材配置</span>
          </Button>
          <Button
            className="tool"
            onClick={() => void fullscreen()}
            aria-label="全屏体验"
          >
            <Maximize />
            <span>全屏</span>
          </Button>
        </div>
      </header>
      <div className="cabin-host" ref={rootRef}>
        <section
          className={`cabin screen-${flow.screen}`}
          aria-label="入画全息舱交互界面"
        >
          <div className="scene-layer" key={scene}>
            {flow.screen === 'home' && !videoFailed ? (
              <video
                ref={videoRef}
                className="scene home-video"
                src={config.homeVideo}
                poster="/assets/video-poster.png"
                autoPlay
                loop
                muted={muted}
                playsInline
                preload="auto"
                onError={() => setVideoFailed(true)}
              >
                <track
                  kind="captions"
                  src="/assets/home.vtt"
                  srcLang="zh"
                  label="动画说明"
                />
              </video>
            ) : (
              <img
                className="scene"
                src={`/assets/${scene}.png`}
                alt=""
                draggable={false}
              />
            )}
          </div>
          <h1 ref={headingRef} tabIndex={-1} className="sr-only">
            {TITLES[flow.screen]}
          </h1>
          {flow.screen === 'home' ? (
            <>
              {!videoFailed && (
                <div className="home-titles">
                  <p>天津美术学院办学120周年</p>
                  <span>入画 · 下一百廿年</span>
                  <h2>预见2146年的自己</h2>
                  <p>未来已经认出你</p>
                </div>
              )}
              <>
                {videoFailed ? (
                  <Hit
                    label="开启未来"
                    box={[30, 61, 40, 21]}
                    round
                    onClick={() => act({ type: 'start' })}
                  />
                ) : (
                  <>
                    <Button
                      className="home-enter"
                      onClick={() => act({ type: 'start' })}
                    >
                      <span>开启未来</span>
                      <ArrowRight />
                    </Button>
                    <p className="home-hint">轻触开启未来，开始你的入画之旅</p>
                  </>
                )}
              </>
              <Button
                className="sound-control"
                onClick={() => {
                  setMuted((v) => !v);
                  void videoRef.current
                    ?.play()
                    .catch(() => setVideoBlocked(true));
                }}
                aria-label={muted ? '开启声音' : '关闭声音'}
              >
                {muted ? <VolumeX /> : <Volume2 />}
              </Button>
              {videoBlocked && (
                <Button
                  className="play-video"
                  onClick={() => {
                    void videoRef.current
                      ?.play()
                      .then(() => setVideoBlocked(false))
                      .catch(() =>
                        setNotice('视频暂时无法播放，可直接开启未来'),
                      );
                  }}
                >
                  播放首页动画
                </Button>
              )}
            </>
          ) : (
            <nav aria-label="页面导航">
              {flow.screen === 'gender' && <><span className="gender-back">‹ 返回</span><span className="gender-home">⌂ 返回首页</span></>}
              <Hit
                label="返回上一级"
                box={[2.5, 1.7, 19, 5]}
                onClick={() => act({ type: 'back' })}
              />
              <Hit
                label="返回首页"
                box={[78, 1.7, 19, 5]}
                onClick={() => {
                  setResult(null);
                  act({ type: 'home' });
                }}
              />
            </nav>
          )}
          {flow.screen === 'gender' && (
            <>
              <div className="gender-heading">
                <p>入画 · 下一百廿年</p>
                <h2>未来的你，<br />想以什么形象登场？</h2>
                <span>轻触一种人物形象，下一步选择未来身份</span>
              </div>
              <div className="gender-choices">
                {(['male', 'female'] as const).map((gender) => (
                  <Button key={gender} className="gender-choice"
                    onClick={() => act({ type: 'gender', gender })}>
                    <span>{GENDER_NAMES[gender]} <ArrowRight /></span>
                  </Button>
                ))}
              </div>
              <p className="gender-footnote">你的未来，由你选择</p>
            </>
          )}
          {flow.screen === 'directions' && (
            <>
              <fieldset className="direction-disc" aria-label="选择一个方向">
                {GROUPS.map((g, i) => (
                  <Button
                    key={g.id}
                    className={`sector sector-${i}`}
                    aria-label={g.name}
                    onClick={() => act({ type: 'direction', group: g.id })}
                  >
                    <span className="sr-only">{g.name}</span>
                  </Button>
                ))}
              </fieldset>
              <Button
                className="all-identities"
                onClick={() => act({ type: 'all' })}
              >
                查看全部身份
                <ArrowRight />
              </Button>
            </>
          )}
          {flow.screen === 'identities' &&
            ORBITS.map(([id, x, y]) => (
              <Hit
                key={id}
                label={IDENTITIES.find((i) => i.id === id)!.name}
                box={[Math.max(0, x - 11), y - 6, 22, 14]}
                round
                onClick={() => act({ type: 'identity', identity: id })}
              />
            ))}
          {flow.screen === 'pair' &&
            IDENTITIES.filter((i) => i.group === flow.group).map(
              (id, index) => (
                <Hit
                  key={id.id}
                  label={id.name}
                  box={[8, index === 0 ? 56 : 72, 84, 15]}
                  onClick={() => act({ type: 'identity', identity: id.id })}
                />
              ),
            )}
          {flow.screen === 'loading' && (
            <>
              <div className="scan-line" aria-hidden="true" />
              <div className="energy-halo" aria-hidden="true" />
              <div className="loading-states" aria-live="polite">
                {STEPS.map((step, i) => (
                  <div
                    key={step}
                    className={`loading-step ${progress >= [0, 30, 60, 100][i] ? 'lit' : ''} ${progress >= [0, 30, 60, 100][i] && progress < [30, 60, 100, 101][i] ? 'current' : ''}`}
                  >
                    <span className="step-orb">
                      {progress >= [30, 60, 100, 101][i] ? '✓' : i + 1}
                    </span>
                    <span>{step}</span>
                  </div>
                ))}
                <Progress
                  value={progress}
                  aria-label="海报准备进度"
                  className="loading-progress"
                />
                {error ? (
                  <div className="load-error" role="alert">
                    <p>{error}</p>
                    <Button onClick={() => act({ type: 'retry' })}>
                      重新尝试
                    </Button>
                    <Button onClick={() => act({ type: 'back' })}>
                      返回选择
                    </Button>
                  </div>
                ) : (
                  <p className="wait-note">
                    {config.generationEndpoint
                      ? '请稍候，你的未来肖像正在生成'
                      : '请稍候，即将展示你的未来肖像'}
                  </p>
                )}
              </div>
            </>
          )}
          {['preview', 'save', 'poster', 'guide'].includes(flow.screen) && (
            <Poster
              result={result}
              identity={identity}
              gender={gender}
              variant={flow.variant}
              kind={flow.screen}
              onError={() => {
                setResult(null);
                setNotice('海报图片无法加载，请返回后重试');
              }}
            />
          )}
          {flow.screen === 'preview' && (
            <>
              <Hit
                label="这就是我，选择保存方式"
                box={[21, 81, 58, 7]}
                onClick={() => act({ type: 'confirm' })}
              />
              <Hit
                label="换一张同身份海报"
                box={[30, 88, 40, 6]}
                onClick={() => act({ type: 'next' })}
              />
            </>
          )}
          {flow.screen === 'save' && (
            <>
              <Hit
                label="纯海报版"
                box={[10, 69.5, 80, 10.8]}
                onClick={() => act({ type: 'format', screen: 'poster' })}
              />
              <Hit
                label="海报加导览版"
                box={[10, 81, 80, 11]}
                onClick={() => act({ type: 'format', screen: 'guide' })}
              />
            </>
          )}
          {['poster', 'guide'].includes(flow.screen) && (
            <>
              <div className={`qr-overlay qr-${flow.screen}`}>
                {qr ? (
                  <img
                    src={qr}
                    alt={
                      flow.screen === 'guide'
                        ? '海报与导览二维码'
                        : '海报下载二维码'
                    }
                  />
                ) : (
                  <div className="qr-empty">二维码待接入</div>
                )}
              </div>
              {result?.imageUrl && (
                <Button
                  className={`local-download download-${flow.screen}`}
                  onClick={download}
                >
                  <Download />
                  下载当前海报
                </Button>
              )}
            </>
          )}
          {flow.screen === 'poster' && (
            <Hit
              label="查看海报加导览版"
              box={[23, 87, 54, 7]}
              onClick={() => act({ type: 'format', screen: 'guide' })}
            />
          )}
          {flow.screen === 'guide' &&
            ['百廿序章', '新艺科现场', '未来艺术家', '时间信舱'].map(
              (name, i) => (
                <Hit
                  key={name}
                  label={`查看${name}导览`}
                  box={[63, 29.4 + i * 10.3, 25, 9.4]}
                  onClick={() => {
                    if (result?.guideUrl)
                      window.open(
                        result.guideUrl,
                        '_blank',
                        'noopener,noreferrer',
                      );
                    else setGuideOpen(name);
                  }}
                />
              ),
            )}
          {!['home', 'gender', 'loading'].includes(flow.screen) && (
            <div className="selection-badge">
              {gender}
              {identity ? ` · ${identity}` : ''}
            </div>
          )}
          <div className="ambient-glow" aria-hidden="true" />
        </section>
      </div>
      <Dialog open={settings} onOpenChange={setSettings}>
        <DialogContent className="settings-panel">
          <DialogTitle>素材配置</DialogTitle>
          <DialogDescription>
            为每种人物形象和身份添加海报。添加多张后，「换一张」会在同一身份内切换。素材仅保留在本次打开的页面中。
          </DialogDescription>
          <div className="config-grid">
            <label htmlFor="asset-gender">
              人物形象
              <Select
                value={assetGender}
                onValueChange={(v) => v && setAssetGender(v as Gender)}
              >
                <SelectTrigger id="asset-gender">
                  <SelectValue>{GENDER_NAMES[assetGender]}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">男生形象</SelectItem>
                  <SelectItem value="female">女生形象</SelectItem>
                </SelectContent>
              </Select>
            </label>
            <label htmlFor="asset-identity">
              未来身份
              <Select
                value={assetId}
                onValueChange={(v) => v && setAssetId(v as Identity)}
              >
                <SelectTrigger id="asset-identity">
                  <SelectValue>
                    {IDENTITIES.find((i) => i.id === assetId)?.name}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {IDENTITIES.map((i) => (
                    <SelectItem key={i.id} value={i.id}>
                      {i.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
          </div>
          <label className="upload-control">
            <ImagePlus />
            <span>添加海报图片（可多选）</span>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              multiple
              onChange={(e) => {
                void addImages(e.target.files);
                e.target.value = '';
              }}
            />
          </label>
          <div className="asset-thumbs">
            {(pool[assetKey] ?? config.posters[assetKey] ?? [])
              .filter((r) => r.imageUrl)
              .map((r, i) => (
                <img
                  key={r.imageUrl}
                  src={r.imageUrl!}
                  alt={`已添加的第${i + 1}张海报`}
                />
              ))}
          </div>
          <p>
            已添加 {(pool[assetKey] ?? config.posters[assetKey] ?? []).filter((r) => r.imageUrl).length} 张
            · 显示比例 942∶1670
          </p>
          <div className="config-grid">
            <label className="upload-control compact">
              纯海报二维码
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => {
                  addQr(e.target.files, 'downloadQr');
                  e.target.value = '';
                }}
              />
            </label>
            <label className="upload-control compact">
              海报＋导览二维码
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => {
                  addQr(e.target.files, 'guideQr');
                  e.target.value = '';
                }}
              />
            </label>
          </div>
          <p className="config-note">
            首页动画已接入。当前
            {config.generationEndpoint
              ? '使用已配置的海报服务'
              : '演示生成流程，尚未接入真实AI生成服务'}
            。二维码请添加与你的海报对应的有效二维码。
          </p>
          <Button className="gold-button" onClick={() => setSettings(false)}>
            完成配置
          </Button>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!guideOpen}
        onOpenChange={(open) => !open && setGuideOpen(null)}
      >
        <DialogContent className="guide-dialog">
          <DialogTitle>{guideOpen}</DialogTitle>
          <DialogDescription>
            展厅导览内容待添加。接入导览后，可在这里继续浏览。
          </DialogDescription>
          <Button className="gold-button" onClick={() => setGuideOpen(null)}>
            返回海报
          </Button>
        </DialogContent>
      </Dialog>
      {notice && <output className="notice">{notice}</output>}
    </main>
  );
}
