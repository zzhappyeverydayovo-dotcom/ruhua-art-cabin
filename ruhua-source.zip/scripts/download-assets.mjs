import { mkdir, writeFile } from 'node:fs/promises';
const origin = process.argv[2];
if (!origin || !/^https?:\/\//.test(origin))
  throw new Error('请传入公开站点的完整HTTP(S)地址');
const names = [
  'home.png',
  'gender.png',
  'directions.png',
  'identities.png',
  'nature.png',
  'tech.png',
  'city.png',
  'heart.png',
  'loading.png',
  'preview.png',
  'save.png',
  'poster.png',
  'guide.png',
  'home-original.mp4',
  'video-poster.png',
  'home.vtt',
];
await mkdir('public/assets', { recursive: true });
for (const name of names) {
  const response = await fetch(new URL('/assets/' + name, origin));
  if (!response.ok) throw Error(name + ': ' + response.status);
  await writeFile(
    'public/assets/' + name,
    Buffer.from(await response.arrayBuffer()),
  );
  console.log('已下载 ' + name);
}

const configResponse = await fetch(new URL('/ruhua-config.json', origin));
if (!configResponse.ok) throw Error('配置下载失败');
const config = await configResponse.json();
await writeFile('public/ruhua-config.json', JSON.stringify(config, null, 2));
await mkdir('public/posters', { recursive: true });
for (const poster of Object.values(config.posters).flat()) {
  if (!/^\/posters\/[a-z0-9-]+\.webp$/.test(poster.imageUrl)) continue;
  const r = await fetch(new URL(poster.imageUrl, origin));
  if (!r.ok) throw Error('海报下载失败：' + poster.imageUrl);
  await writeFile('public' + poster.imageUrl, Buffer.from(await r.arrayBuffer()));
}
