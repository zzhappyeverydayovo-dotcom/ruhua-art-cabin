export type Gender = 'male' | 'female';
export const IDENTITIES = [
  { id: 'oriental', name: '东方智绘师', group: 'nature' },
  { id: 'life', name: '生命织造设计师', group: 'nature' },
  { id: 'ai', name: 'AI共生艺术家', group: 'tech' },
  { id: 'objects', name: '智能器物设计师', group: 'tech' },
  { id: 'dimensions', name: '多维造型艺术家', group: 'city' },
  { id: 'cosmos', name: '宇宙叙事建筑师', group: 'city' },
  { id: 'heritage', name: '非遗再生艺术家', group: 'heart' },
  { id: 'emotion', name: '心灵感知艺术家', group: 'heart' },
] as const;
export const GROUPS = [
  { id: 'nature', name: '自然与生命' },
  { id: 'tech', name: '智能与科技' },
  { id: 'city', name: '城市与空间' },
  { id: 'heart', name: '情感与心灵' },
] as const;
export type Identity = (typeof IDENTITIES)[number]['id'];
export type Group = (typeof GROUPS)[number]['id'];
export type Screen =
  | 'home'
  | 'gender'
  | 'directions'
  | 'identities'
  | 'pair'
  | 'loading'
  | 'preview'
  | 'save'
  | 'poster'
  | 'guide';
export interface Flow {
  screen: Screen;
  gender: Gender | null;
  group: Group | null;
  identity: Identity | null;
  variant: number;
  origin: 'pair' | 'identities';
  history: Screen[];
  job: number;
}
export const initialFlow: Flow = {
  screen: 'home',
  gender: null,
  group: null,
  identity: null,
  variant: 0,
  origin: 'identities',
  history: [],
  job: 0,
};
export type Action =
  | { type: 'start' }
  | { type: 'gender'; gender: Gender }
  | { type: 'direction'; group: Group }
  | { type: 'all' }
  | { type: 'identity'; identity: Identity }
  | { type: 'ready'; job: number }
  | { type: 'retry' }
  | { type: 'next' }
  | { type: 'confirm' }
  | { type: 'format'; screen: 'poster' | 'guide' }
  | { type: 'back' }
  | { type: 'home' };
export function reducer(s: Flow, a: Action): Flow {
  const go = (screen: Screen, extra: Partial<Flow> = {}) => ({
    ...s,
    ...extra,
    screen,
    history: [...s.history, s.screen],
  });
  switch (a.type) {
    case 'start':
      return s.screen === 'home' ? go('gender') : s;
    case 'gender':
      return s.screen === 'gender' && ['male', 'female'].includes(a.gender)
        ? go('directions', {
            gender: a.gender,
            identity: null,
            variant: 0,
            group: null,
          })
        : s;
    case 'direction':
      return s.screen === 'directions' && GROUPS.some((g) => g.id === a.group)
        ? go('pair', { group: a.group })
        : s;
    case 'all':
      return s.screen === 'directions' ? go('identities') : s;
    case 'identity': {
      const id = IDENTITIES.find((i) => i.id === a.identity);
      if (
        !s.gender ||
        !id ||
        !['pair', 'identities'].includes(s.screen) ||
        (s.screen === 'pair' && id.group !== s.group)
      )
        return s;
      return {
        ...s,
        screen: 'loading',
        identity: id.id,
        group: id.group,
        variant: 0,
        origin: s.screen as 'pair' | 'identities',
        job: s.job + 1,
      };
    }
    case 'ready':
      return s.screen === 'loading' && s.job === a.job
        ? { ...s, screen: 'preview' }
        : s;
    case 'retry':
      return s.screen === 'loading' ? { ...s, job: s.job + 1 } : s;
    case 'next':
      return s.screen === 'preview'
        ? { ...s, screen: 'loading', variant: s.variant + 1, job: s.job + 1 }
        : s;
    case 'confirm':
      return s.screen === 'preview' ? go('save') : s;
    case 'format':
      return ['save', 'poster', 'guide'].includes(s.screen) &&
        a.screen !== s.screen
        ? go(a.screen)
        : s;
    case 'back':
      if (s.screen === 'home') return s;
      if (['loading', 'preview'].includes(s.screen))
        return { ...s, screen: s.origin, job: s.job + 1 };
      return {
        ...s,
        screen: s.history.at(-1) ?? 'home',
        history: s.history.slice(0, -1),
        job: s.job + 1,
      };
    case 'home':
      return { ...initialFlow, job: s.job + 1 };
  }
}
export interface Result {
  imageUrl: string | null;
  downloadUrl?: string;
  guideUrl?: string;
  downloadQr?: string;
  guideQr?: string;
  demo: boolean;
}
export function safeUrl(value: unknown): string | undefined {
  if (typeof value !== 'string' || !value) return;
  if (value.startsWith('/') && !value.startsWith('//')) return value;
  try {
    const u = new URL(value);
    if (u.protocol === 'https:' || u.protocol === 'http:') return u.href;
  } catch {}
  return;
}
export function parseResult(v: unknown): Result {
  if (!v || typeof v !== 'object') throw Error('海报服务返回了无效结果');
  const r = v as Record<string, unknown>;
  const url = safeUrl(r.imageUrl);
  if (!url) throw Error('海报服务尚未返回可显示的图片');
  return {
    imageUrl: url,
    downloadUrl: safeUrl(r.downloadUrl),
    guideUrl: safeUrl(r.guideUrl),
    downloadQr: safeUrl(r.downloadQr),
    guideQr: safeUrl(r.guideQr),
    demo: false,
  };
}
