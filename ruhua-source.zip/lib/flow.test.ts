import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  initialFlow,
  reducer,
  IDENTITIES,
  GROUPS,
  parseResult,
  safeUrl,
} from './flow.ts';
void test('16 gender/identity combinations retain selections through confirmation and formats', () => {
  for (const gender of ['male', 'female'] as const) {
    for (const id of IDENTITIES) {
      let s = reducer(initialFlow, { type: 'start' });
      s = reducer(s, { type: 'gender', gender });
      s = reducer(s, { type: 'all' });
      s = reducer(s, { type: 'identity', identity: id.id });
      const job = s.job;
      s = reducer(s, { type: 'ready', job });
      s = reducer(s, { type: 'confirm' });
      s = reducer(s, { type: 'format', screen: 'poster' });
      s = reducer(s, { type: 'format', screen: 'guide' });
      assert.equal(s.screen, 'guide');
      assert.equal(s.gender, gender);
      assert.equal(s.identity, id.id);
      s = reducer(s, { type: 'back' });
      assert.equal(s.screen, 'poster');
      s = reducer(s, { type: 'back' });
      assert.equal(s.screen, 'save');
      s = reducer(s, { type: 'back' });
      assert.equal(s.screen, 'preview');
      s = reducer(s, { type: 'back' });
      assert.equal(s.screen, 'identities');
    }
  }
});
void test('four fixed pairs reject unrelated identities', () => {
  for (const g of GROUPS) {
    let s = reducer(initialFlow, { type: 'start' });
    s = reducer(s, { type: 'gender', gender: 'male' });
    s = reducer(s, { type: 'direction', group: g.id });
    const bad = IDENTITIES.find((i) => i.group !== g.id)!;
    assert.equal(reducer(s, { type: 'identity', identity: bad.id }), s);
    for (const id of IDENTITIES.filter((i) => i.group === g.id)) {
      const loading = reducer(s, { type: 'identity', identity: id.id });
      assert.equal(loading.screen, 'loading');
      assert.equal(reducer(loading, { type: 'back' }).screen, 'pair');
    }
  }
});
void test('changing pose retains gender and identity and invalidates stale jobs', () => {
  let s = reducer(initialFlow, { type: 'start' });
  s = reducer(s, { type: 'gender', gender: 'female' });
  s = reducer(s, { type: 'all' });
  s = reducer(s, { type: 'identity', identity: 'life' });
  const old = s.job;
  s = reducer(s, { type: 'ready', job: old });
  s = reducer(s, { type: 'next' });
  assert.equal(s.variant, 1);
  assert.equal(s.identity, 'life');
  assert.equal(s.gender, 'female');
  assert.equal(reducer(s, { type: 'ready', job: old }).screen, 'loading');
  const h = reducer(s, { type: 'home' });
  assert.equal(h.gender, null);
  assert.equal(reducer(h, { type: 'ready', job: s.job }).screen, 'home');
});
void test('invalid screen jumps and unsafe service URLs are rejected', () => {
  assert.equal(reducer(initialFlow, { type: 'confirm' }), initialFlow);
  assert.equal(
    reducer(initialFlow, { type: 'identity', identity: 'life' }),
    initialFlow,
  );
  assert.equal(safeUrl('javascript:alert(1)'), undefined);
  assert.equal(safeUrl('//evil.test'), undefined);
  assert.equal(safeUrl('/assets/a.png'), '/assets/a.png');
  assert.throws(() => parseResult({ imageUrl: 'javascript:alert(1)' }));
  assert.equal(
    parseResult({ imageUrl: 'https://example.com/poster.png' }).demo,
    false,
  );
});

void test('the supplied catalog covers all 16 choices with two real files each', async () => {
  const { readFile, access } = await import('node:fs/promises');
  const config = JSON.parse(await readFile(new URL('../public/ruhua-config.json', import.meta.url), 'utf8'));
  const images = new Set<string>();
  for (const gender of ['male', 'female']) for (const identity of IDENTITIES) {
    const posters = config.posters[`${gender}:${identity.id}`];
    assert.equal(posters.length, 2);
    for (const [index, poster] of posters.entries()) {
      assert.equal(poster.imageUrl, `/posters/${gender}-${identity.id}-${index + 1}.webp`);
      await access(new URL(`../public${poster.imageUrl}`, import.meta.url));
      images.add(poster.imageUrl);
    }
  }
  assert.equal(images.size, 32);
});
